import "./App.css";
import Navbar from "./components/Navbar";
import Home from "./components/Home";
import { BrowserRouter, Route } from "react-router-dom";
import Order from "./components/order";
import Build from "./components/build";
import CopyRight from "./components/copyright";
import MyOrders from "./components/myOrders";
import Admin from "./components/admin";
function App() {
  return (
    <div>
      <BrowserRouter>
        <Route path="/" component={Navbar} />
        <Route path="/home" component={Home} />
        <Route path="/order" component={Order} />
        <Route path="/build" component={Build} />
        <Route path="/orders" component={MyOrders} />
        <Route path="/admin" component={Admin} />
        <Route path="/" exact component={Home} />
        <Route path="/" component={CopyRight} />
      </BrowserRouter>
    </div>
  );
}

export default App;
