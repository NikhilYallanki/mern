export const add = (obj) => {
  return {
    type: "ADD_ITEM",
    payload: obj,
  };
};

export const getCart = () => {
  return {
    type: "GET_ITEMS",
  };
};

export const deleteItem = (obj) => {
  return {
    type: "REMOVE_ITEM",
    payload: obj,
  };
};

export const deleteAllItems = () => {
  return {
    type: "REMOVE_ALLITEMS",
  };
};

export const decrease = (obj) => {
  return {
    type: "DECREASE_ITEM",
    payload: obj,
  };
};
