export const logged = (username) => {
  return {
    type: "LOGGED_IN",
    payload: username,
  };
};

export const logout = () => {
  return {
    type: "LOGGED_OUT",
  };
};
