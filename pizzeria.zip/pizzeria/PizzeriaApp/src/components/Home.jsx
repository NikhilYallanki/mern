import React from "react";
import "bootstrap/dist/css/bootstrap.css";
function Home() {
  return (
    <div className="homepage container-lg mx-lg-auto">
      <h1>Our story </h1>
      <p style={{ marginTop: "20px" }}>
        We believe in good We launched Fresh Pan Pizza Best Excuse Awards on our
        Facebook fan page. Fans were given stuations where they had to come up
        with wacky and fun excuses The person with the best excuse won the Best
        Excuse Badge and won Pizzeria's vouchers. Their enthusiastic response
        proved that Pizzeria's Fresh Pan Pizza is the Tastiest Pan Pizza Ever!
        <br />
        <br />
        Ever since we launched the Tastiest Pan Pizza, ever, people have not
        been able to resist the softest, cheesiest, crunchiest,butteriest
        Domino's Fresh Pan Pizza. They have been leaving the stage in the middle
        of a performance and even finding excuses to be disqualified in a
        football match. <br />
        <br />
        We launched Fresh Pan Pizza Best Excuse Awards on our Facebook fan page.
        Fans were given stuations where they had to come up with wacky and fun
        excuses The person with the best excuse won the Best Excuse Badge and
        won Pizzeria's vouchers. Their enthusiastic response proved that
        Pizzeria's Fresh Pan Pizza is the Tastiest Pan Pizza Ever!
      </p>
      <div className="contain container-lg mx-lg-auto mt-5">
        <img
          src="/ingredients.jpg"
          style={{ height: "220px", width: "300px" }}
          alt=""
        />
        <div className="right ms-5">
          <h3>Ingredients</h3>
          <p>
            We're ruthless about goodness. We have no qualms about tearing up a
            day-old lettuce leaf (straight from the farm), or steaming a baby
            (carrot). Cut. Cut. Chop. Chop. Steam. Steam. Stir. Stir. While
            they're still young and fresh -that's our motto. It makes the
            kitchen a better place
          </p>
        </div>
      </div>
      <div className="contain1 container-lg mx-lg-auto mt-5">
        <div className="right  me-5">
          <h3>Our Chefs</h3>
          <p>
            They make sauces sing and salads dance. They create magic with
            skill, knowledge, passion, and stirring spoons (among other things).
            They make goodness so good, it doesn't know what to do with itself.
            We do though. We send it to you.
          </p>
        </div>
        <img
          src="/chef.jpg"
          style={{ height: "220px", width: "300px" }}
          alt=""
        />
      </div>
      <div className="contain container-lg mx-lg-auto mb-3 mt-5">
        <img src="/clock.jpg" alt="" />
        <h3 className="ms-5">45 min delivery</h3>
      </div>
    </div>
  );
}

export default Home;
