import React, { useEffect, useState } from "react";
import "jquery/dist/jquery.slim.js";
import "font-awesome/css/font-awesome.min.css";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import ModalTest from "../subcomponents/modal";
import "bootstrap/js/src/collapse.js";
import Login from "./login";
import Dropdown from "react-bootstrap/Dropdown";
import { logout } from "../actions/user";
import showAlert from "../subcomponents/showAlert";

function Navbar() {
  const myOrders = useSelector((state) => state.cartReducer);
  const [color, setColor] = useState("bg-secondary");
  const user = useSelector((state) => state.userReducer);
  const dispatch = useDispatch();
  useEffect(() => {
    if (myOrders.length > 0) setColor("bg-info");
    else setColor("bg-secondary");
  }, [myOrders]);
  /*  useEffect(() => { 
    $(".menu Link").on("click", function () {
      $(".menu").hide();
    });
  }); */
  const closeNavRight = () => {
    let x = document.getElementById("hide-right");
    //delay buttons as it defaults to flex column on click burger
    if (x.style.display === "none") {
      setTimeout(() => {
        x.style.display = "flex";
      }, 500);
    } else {
      setTimeout(() => {
        x.style.display = "none";
      }, 0);
    }
  };
  return (
    <>
      <nav className="navbar navbar-expand-md navbar-dark bg-dark master-nav sticky-top">
        <div className="container-fluid">
          <div className="nav-left">
            {/* burger menu contents */}
            <div className="collapse" id="navbarToggleExternalContent">
              <div className="bg-dark p-4 hamburger-collapse" id="menu">
                <Link
                  to="/home"
                  className="navbar-brand"
                  style={{ color: "grey" }}
                >
                  <button
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarToggleExternalContent"
                    onClick={closeNavRight}
                  >
                    Pizzeria
                  </button>
                </Link>
                <Link
                  to="/order"
                  className="navbar-brand"
                  style={{ color: "grey" }}
                >
                  <button
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarToggleExternalContent"
                    onClick={closeNavRight}
                  >
                    Order Pizza
                  </button>
                </Link>
                <Link
                  to="/build"
                  className="navbar-brand"
                  style={{ color: "grey" }}
                >
                  <button
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarToggleExternalContent"
                    onClick={closeNavRight}
                  >
                    Build Ur Pizza
                  </button>
                </Link>
                <Link
                  to="/orders"
                  className="navbar-brand"
                  style={{ color: "grey" }}
                >
                  <button
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarToggleExternalContent"
                    onClick={closeNavRight}
                  >
                    My Orders
                  </button>
                </Link>
                <Link
                  to="/admin"
                  className="navbar-brand"
                  style={{ color: "grey" }}
                >
                  <button
                    data-bs-toggle="collapse"
                    data-bs-target="#navbarToggleExternalContent"
                    onClick={closeNavRight}
                  >
                    Admin
                  </button>
                </Link>
              </div>
            </div>
            {/* burger menu */}
            <button
              className="navbar-toggler hamburger"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarToggleExternalContent"
              aria-controls="navbarToggleExternalContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
              onClick={closeNavRight}
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            {/* show on large screens, no burger menu */}
            <div className="largescreen-text">
              <Link
                to="/home"
                className="navbar-brand firstLink"
                href="#"
                style={{ color: "grey" }}
              >
                Pizzeria
              </Link>
              <Link to="/home" className="navbar-image">
                <img
                  src="/PizzeriaLogo.png"
                  alt=""
                  width="50"
                  height="40"
                  className="d-inline-block align-text-top"
                />
              </Link>
              <div
                className="collapse navbar-collapse"
                id="navbarSupportedContent"
              >
                <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                  <li className="nav-item">
                    <Link to="/order" className="nav-link">
                      Order Pizza
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to="/build" className="nav-link">
                      Build Ur Pizza
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to="/orders" className="nav-link">
                      My Orders
                    </Link>
                  </li>
                  <>
                    <li className="nav-item">
                      <Link to="/admin" className="nav-link">
                        Admin
                      </Link>
                    </li>
                  </>
                </ul>
              </div>
            </div>
          </div>
          {/* login,counter,cart */}
          <div className="nav-right" id="hide-right">
            {/* if not logged in show login button*/}
            {user === "" ? (
              <div className="login">
                <Login /> &nbsp;
              </div>
            ) : (
              <>
                {/* if logged in show username button*/}
                <Dropdown>
                  <Dropdown.Toggle
                    variant="success"
                    id="dropdown-basic"
                    style={{ marginRight: "10px" }}
                    className="nav-userInfo"
                  >
                    <i className="fa fa-user"> {user}</i>
                  </Dropdown.Toggle>

                  <Dropdown.Menu>
                    <Dropdown.Item
                      onClick={() => {
                        dispatch(logout());
                        showAlert(
                          "Logged out successfully",
                          "success",
                          "center"
                        );
                      }}
                    >
                      Logout
                    </Dropdown.Item>
                  </Dropdown.Menu>
                </Dropdown>
              </>
            )}
            {/* mycart area */}
            <div className="nav-cart">
              {/* counter */}
              <span
                className={`badge ${color} text-dark rounded-pill`}
                id="mycounter"
              >
                {myOrders.length}
              </span>
              {/* mycart button */}
              <ModalTest id="myCart" />
            </div>
          </div>
        </div>
      </nav>
    </>
  );
}

export default Navbar;
