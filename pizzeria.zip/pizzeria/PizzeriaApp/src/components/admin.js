import axios from "axios";
import { useEffect, useState } from "react";
function Admin() {
  const [allOrders, setAllOrders] = useState([]);
  useEffect(() => {
    axios
      .get("http://localhost:3001/admin")
      .then((res) => setAllOrders(res.data));
  }, []);
  /*  const handleUpdate = (username, orderId) => {
    // console.log(username + " " + orderId);
    axios.post("http://localhost:3001/adminUpdate", {
      username: username,
      orderId: orderId,
    });
  }; */
  /* //socket
  const io = require("socket.io")(9999, {
    cors: {
      origin: ["http://localhost:3000"],
    },
  });

  io.on("connection", (socket) => {
    io.emit("event", "test");
  }); */
  const sendUpdateActivity = (username, orderId, s) => {
    axios.post("http://localhost:3001/adminActivityUpdate", {
      username: username,
      orderId: orderId,
      status: s,
    });
  };
  const handleNameChange = (index, ind, s) => {
    let x = document.getElementById(`dropdownMenuButton_${index}_${ind}`);
    x.innerHTML = s;
  };

  return (
    <>
      {allOrders.length === 0 ? (
        <h3
          style={{ textAlign: "center", fontWeight: "bold", marginTop: "20px" }}
        >
          No orders
        </h3>
      ) : (
        <table className="table table-bordered ">
          <thead className="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Username</th>
              <th scope="col">Orders</th>
              <th scope="col">Address</th>
              <th scope="col">Total</th>
              <th scope="col">Confirm </th>
            </tr>
          </thead>
          <tbody>
            {allOrders.map((o, index) => {
              return (
                <tr key={`tr_${index}`}>
                  <th scope="row" key={`th_${index}`}>
                    {index + 1}
                  </th>
                  <td key={`td_${index}`}>{o.username}</td>

                  <td>
                    {o.orders.map((so, i) => {
                      if (so.status !== "delivered") {
                        return (
                          <div key={`rand_${i}`}>
                            {so.getCurrentOrders.map((soo, ind) => {
                              return <p key={`p_${ind}`}>{soo}</p>;
                            })}
                            <hr style={{ height: "1.8px" }}></hr>
                          </div>
                        );
                      }
                      return null;
                    })}
                  </td>
                  <td>
                    {o.orders.map((so, ind) => {
                      if (so.status !== "delivered") {
                        return (
                          <i key={`address_${ind}`}>
                            {so.address} <hr style={{ height: "1.8px" }}></hr>
                          </i>
                        );
                      }
                      return null;
                    })}
                  </td>
                  <td>
                    {o.orders.map((so, ind) => {
                      if (so.status !== "delivered") {
                        return (
                          <i key={`tot_${ind}`}>
                            &#8377;{so.tot}{" "}
                            <hr style={{ height: "1.8px" }}></hr>
                          </i>
                        );
                      }
                      return null;
                    })}
                  </td>

                  <td>
                    {o.orders.map((so, ind) => {
                      if (so.status !== "delivered") {
                        return (
                          <>
                            <div className="dropdown" key={`dropdown_${ind}`}>
                              <button
                                className="btn btn-secondary dropdown-toggle"
                                type="button"
                                id={`dropdownMenuButton_${index}_${ind}`}
                                data-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                              >
                                {so.status}
                              </button>
                              <div
                                className="dropdown-menu"
                                aria-labelledby="dropdownMenuButton"
                                key={`div_${ind}`}
                              >
                                {/* eslint-disable-next-line */}
                                <a
                                  className="dropdown-item"
                                  style={{ cursor: "pointer" }}
                                  onClick={() => {
                                    sendUpdateActivity(
                                      o.username,
                                      so.orderId,
                                      "ready"
                                    );
                                    handleNameChange(index, ind, "ready");
                                  }}
                                >
                                  Ready
                                </a>
                                {/* eslint-disable-next-line */}
                                <a
                                  className="dropdown-item"
                                  style={{ cursor: "pointer" }}
                                  onClick={() => {
                                    sendUpdateActivity(
                                      o.username,
                                      so.orderId,
                                      "delivering"
                                    );
                                    handleNameChange(index, ind, "delivering");
                                  }}
                                >
                                  Delivering
                                </a>
                                {/* eslint-disable-next-line */}
                                <a
                                  className="dropdown-item"
                                  style={{ cursor: "pointer" }}
                                  onClick={() => {
                                    sendUpdateActivity(
                                      o.username,
                                      so.orderId,
                                      "delivered"
                                    );
                                    handleNameChange(index, ind, "delivered");
                                  }}
                                >
                                  Delivered
                                </a>
                              </div>
                            </div>
                            <hr style={{ height: "1.8px" }}></hr>
                          </>
                        );
                      }
                      return null;
                    })}
                  </td>
                </tr>
              );
            })}
          </tbody>
          {/* <tfoot>
          <button className="btn btn-primary" onClick={handleUpdate}>
            Submit
          </button>
        </tfoot> */}
        </table>
      )}
    </>
  );
}

export default Admin;

/* <input
                          className="form-check-input mycheckbox"
                          style={{ marginLeft: "10px" }}
                          type="checkbox"
                          onClick={() => handleUpdate(o.username, so.orderId)}
                        /> */
