// import ingredients from "./ingredients.json";
import "bootstrap/dist/css/bootstrap.css";
import { useEffect, useState } from "react";
import { add } from "../actions/cart";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import showAlert from "../subcomponents/showAlert";
function Build() {
  const [total, setTotal] = useState(0);
  const [ingredients, setIng] = useState([]);
  const myOrders = useSelector((state) => state.cartReducer);
  const dispatch = useDispatch();
  //read ingredients from mongodb on mount
  useEffect(() => {
    axios.get("http://localhost:3001/readIng").then((res) => {
      setIng(res.data);
    });
  }, []);
  //onsubmit remove all checkedboxes
  const handleUncheckBoxes = () => {
    let box = document.getElementsByClassName("mycheckbox");
    for (let i = 0; i < box.length; i++) {
      if (box[i].checked === true) box[i].checked = false;
    }
  };
  //get final total 
  const calculateTotal = (price, index) => {
    const x = document.getElementById(`checkbox${index}`);
    // console.log(x);
    if (x.checked === true) setTotal(total + price);
    else setTotal(total - price);
  };

  return (
    <>
      <p style={{ textAlign: "center", margin: "30px 0px" }}>
        Pizzeria now gives you options to build your own pizza. Customize your
        pizza by choosing ingredients from the list given below
      </p>
      <div className="mybuild ">
        <div className="container-mybuild">
          <table className="table table-striped table-bordered">
            <tbody>
              {ingredients.map((ing, index) => {
                return (
                  <tr className="table-ing" key={ing.id}>
                    <td>
                      <img
                        src={ing.image}
                        className="img-thumbnail me-5"
                        alt=""
                      />{" "}
                    </td>
                    <td className="align-p-toimage">
                      <p style={{ width: "100%", margin: "10px" }}>
                        <b>
                          {ing.tname}&nbsp;&nbsp;&#8377;{ing.price}
                        </b>
                      </p>
                    </td>
                    <td className="align-p-toimage">
                      <div
                        style={{ marginLeft: "20px" }}
                        className="form-check me-5"
                      >
                        <input
                          className="form-check-input mycheckbox "
                          type="checkbox"
                          value=""
                          id={`checkbox${index}`}
                          onClick={() => {
                            calculateTotal(ing.price, index);
                          }}
                        />
                        <label
                          style={{
                            color: "rgb(255, 174, 0)",
                          }}
                          className="form-check-label"
                          htmlFor="flexCheckDefault"
                        >
                          Add
                        </label>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {/* additional Rs.50 for pizza base */}
          <div className="mybuild footer">
            <p className="p-cost">Cost of Ingredients: {total} </p>
            <p className="p-cost">Total Cost: {50 + total} </p>
            <button
              className="button-cost"
              id="msgSuccess"
              onClick={() => {
                // calculateTotal();
                dispatch(
                  add({
                    id: myOrders.length + 1,
                    price: 50 + total,
                    name: `Built Pizza`,
                  })
                );
                handleUncheckBoxes(myOrders);
                setTotal(0);
                showAlert("Built Pizza");
              }}
            >
              Build Ur Pizza
            </button>
          </div>
        </div>
      </div>
    </>
  );
}

export default Build;
