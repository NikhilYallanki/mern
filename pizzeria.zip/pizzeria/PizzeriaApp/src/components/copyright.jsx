import React from "react";
function CopyRight() {
  return (
    <p
      className="copyright"
      style={{ textAlign: "center", color: "rgb(255, 174, 0)" }}
    >
      Copyrights @2021 Pizzeria. All rights reserved.
    </p>
  );
}

export default CopyRight;
