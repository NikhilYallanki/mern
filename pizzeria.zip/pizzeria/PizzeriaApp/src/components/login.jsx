/* eslint-disable jsx-a11y/anchor-is-valid */
import axios from "axios";
import { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useDispatch } from "react-redux";
import { logged } from "../actions/user";
import showAlert from "../subcomponents/showAlert";
import Register from "./register";
function Login() {
  const [show, setShow] = useState(false);
  const [input, setInput] = useState("");
  const [password, setPassword] = useState("");
  const [showRegister, setshowRegister] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const dispatch = useDispatch();
  //open new modal menu if user clicks on register
  const handleResetRegister = async () => {
    //await because setting state is queued and if not used opens and closes immediately when dequeued
    if (!showRegister) await setshowRegister(true);
    else {
      await setshowRegister(false);
      await setshowRegister(true);
    }
  };
  //login backend
  const validateLogin = async (e) => {
    await axios
      .post("http://localhost:3001/users", {
        username: input,
        password: password,
      })
      .then((res) => {
        if (res.data === false) showAlert("Login failed", "danger","center");
        else {
          dispatch(logged(input));
          showAlert("Login Success", "success", "center");
        }
      })
      .catch((e) => console.log(e));
  };
  //controlled form
  return (
    <>
      <Button variant="primary" onClick={handleShow}>
        Login
      </Button>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Login</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form>
            <div className="form-outline mb-4">
              <input
                type="text"
                id="form2Example1"
                className="form-control"
                onChange={(e) => setInput(e.target.value)}
                value={input}
              />
              <label className="form-label">Username</label>
            </div>

            <div className="form-outline mb-4">
              <input
                type="password"
                id="form2Example2"
                className="form-control"
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                value={password}
              />
              <label className="form-label">Password</label>
            </div>

            <button
              type="button"
              className="btn btn-primary btn-block mb-4"
              onClick={() => {
                validateLogin();
                handleClose();
              }}
            >
              Sign in
            </button>
          </form>
          <p>
            Don't have an account? Register{" "}
            <a
              style={{ cursor: "pointer", textDecoration: "underline" }}
              onClick={() => {
                handleClose();
                handleResetRegister();
              }}
            >
              here
            </a>
          </p>
        </Modal.Body>
      </Modal>
      {showRegister ? <Register /> : null}
    </>
  );
}

export default Login;
