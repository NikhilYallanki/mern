import axios from "axios";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";

function MyOrders() {
  const [orders, setOrders] = useState([]);
  const username = useSelector((state) => state.userReducer);
  //generate key  for tables unique key
  const generateKey = (pre) => {
    return `${pre}_${new Date().getTime()}`;
  };
  const user = useSelector((state) => state.userReducer);
  useEffect(() => {
    async function gets(req, res) {
      try {
        await axios
          .post("http://localhost:3001/orderHistory", {
            username: username,
          })
          .then((res) => {
            const x = res.data;
            setOrders(x);
          });
      } catch (e) {
        console.log(e);
      }
    }
    //is user logged in get history else no
    // eslint-disable-next-line no-unused-expressions
    user ? gets() : null;
  }, [user, username]);
  const handleRefresh = () => {
    async function gets(req, res) {
      try {
        await axios
          .post("http://localhost:3001/orderHistory", {
            username: username,
          })
          .then((res) => {
            const x = res.data;
            setOrders(x);
          });
      } catch (e) {
        console.log(e);
      }
    }
    gets();
  };
  return (
    <>
      <div
        style={{
          margin: "15px 0px",
          display: "flex",
          justifyContent: "center",
        }}
      >
        <h2>Your Orders </h2>
        {user.length > 0 ? (
          <button
            id="refresh"
            className="btn btn-secondary"
            onClick={handleRefresh}
            style={{ marginLeft: "5px" }}
          >
            Refresh
          </button>
        ) : null}
      </div>
      {orders.length ? (
        <div className="orderHistory">
          <table className="table table-bordered">
            <thead className="thead-dark">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Name</th>
                <th scope="col">Status</th>
                <th scope="col">Total</th>
              </tr>
            </thead>
            <tbody>
              {orders.map((o, index) => {
                return (
                  <tr key={generateKey(`tr-${index}`)}>
                    <th scope="row" key={generateKey(`th-${index}`)}>
                      {index + 1}
                    </th>
                    <td key={generateKey(`td-${index}`)}>
                      {o.getCurrentOrders.map((so, ind) => {
                        return <p key={generateKey(`so-${ind}`)}>{so}</p>;
                      })}
                    </td>
                    <td>{o.status}</td>
                    <td>&#8377;{o.tot}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      ) : username.length === 0 ? (
        <p style={{ textAlign: "center", fontWeight: "bold" }}>
          Login To See Your Order History.
        </p>
      ) : (
        <p style={{ textAlign: "center", fontWeight: "bold" }}>
          No Order History.
        </p>
      )}
    </>
  );
}

export default MyOrders;
