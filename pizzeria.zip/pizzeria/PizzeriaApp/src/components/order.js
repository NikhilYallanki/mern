// import pizzas from "./pizza.json";
import "bootstrap/dist/css/bootstrap.css";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { add } from "../actions/cart";
import axios from "axios";
import "bootstrap-notify/bootstrap-notify";
import "animate.css";
import showAlert from "../subcomponents/showAlert";
function Order() {
  const [pizzas, setPizzas] = useState([]);
  // read pizzas from mongodb on mount
  useEffect(() => {
    axios.get("http://localhost:3001/read").then((res) => setPizzas(res.data));
  }, []);
  const dispatch = useDispatch();

  const handleDispatch = (pizza, times) => {
    for (let i = 0; i < times; i++) dispatch(add(pizza));
  };
  const handleGetDropDownValue = (index) => {
    const x = document.getElementById(`dropDown_${index}`);
    return x.value;
  };
  return (
    <>
      <div className="allcards">
        {pizzas.map((pizza, index) => {
          return (
            <div
              key={index}
              className="card mb-3 item"
              style={{ maxWidth: "540px" }}
            >
              <div className="row g-0">
                <div className="col-md-3">
                  <div className="card-body">
                    <h5 className="card-title">
                      {pizza.name}
                      <br />
                      <img className={pizza.type} alt="" />
                    </h5>
                    <p className="card-text card-price">
                      <b>
                        &#8377;
                        {pizza.price}
                      </b>
                    </p>
                  </div>
                </div>
                <div className="col-md-5">
                  <div className="card-body">
                    <p className="card-text">
                      {pizza.description}
                      <br></br>
                    </p>
                    <p className="card-text">
                      <strong>Ingredients : </strong>
                      {pizza.ingredients.map((i) => {
                        return i + ", ";
                      })}
                    </p>
                    <p className="card-text">
                      <strong>Toppings : </strong>
                      {pizza.topping.map((top) => {
                        return top + ", ";
                      })}
                    </p>
                  </div>
                </div>
                <div className="col-md-4 mobile-center-order">
                  <img
                    src={pizza.image}
                    className="img-fluid rounded-start"
                    alt=""
                  />
                  <button
                    onClick={() => {
                      const times = handleGetDropDownValue(index);
                      handleDispatch(pizza, times);
                      showAlert(pizza.name + " added");
                    }}
                    className="btn btn-warning button-align"
                  >
                    Add to Cart
                  </button>
                  <select
                    defaultValue="1"
                    className="bootstrap-select btn btn-secondary btn-sm"
                    id={`dropDown_${index}`}
                    style={{
                      marginLeft: "50px",

                      background: "rgb(104,104,104)",
                    }}
                  >
                    <option value="1">Qty</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                    <option value="6">6</option>
                    <option value="7">7</option>
                    <option value="8">8</option>
                    <option value="9">9</option>
                    <option value="10">10</option>
                  </select>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

export default Order;
