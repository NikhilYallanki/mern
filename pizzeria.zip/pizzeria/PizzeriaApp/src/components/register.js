import axios from "axios";
import { useState } from "react";
import Modal from "react-bootstrap/Modal";
import showAlert from "../subcomponents/showAlert";
function Register() {
  const [show, setShow] = useState(true);
  const [input, setInput] = useState("");
  const [password, setPassword] = useState("");
  const handleClose = () => setShow(false);
  const validateRegister = async (e) => {
    // e.preventDefault();
    await axios
      .post("http://localhost:3001/insert", {
        username: input,
        password: password,
      })
      .then((res) => {
        if (res.data === "exists")
          showAlert(
            "Username exists.Register with a different username",
            "danger",
            "center"
          );
        else if (res.data === false) showAlert("Register failed");
        else showAlert("Register Success.Please Login", "info", "center");
      })
      .catch((e) => console.log(e));
  };

  return (
    <>
      <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Register</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <form>
            <div className="form-outline mb-4">
              <input
                type="text"
                id="form2Example1"
                className="form-control"
                onChange={(e) => setInput(e.target.value)}
                value={input}
              />
              <label className="form-label">Username</label>
            </div>

            <div className="form-outline mb-4">
              <input
                type="password"
                id="form2Example2"
                className="form-control"
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
                value={password}
              />
              <label className="form-label">Password</label>
            </div>

            <button
              type="button"
              className="btn btn-primary btn-block mb-4"
              onClick={() => {
                validateRegister();
                handleClose();
              }}
            >
              Register
            </button>
          </form>
        </Modal.Body>
      </Modal>
    </>
  );
}

export default Register;
