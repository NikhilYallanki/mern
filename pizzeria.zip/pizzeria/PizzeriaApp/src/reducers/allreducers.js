import cartReducer from "./cart";
import { combineReducers } from "redux";
import userReducer from "./userReducer";
const allReducers = combineReducers({ cartReducer, userReducer });
export default allReducers;
