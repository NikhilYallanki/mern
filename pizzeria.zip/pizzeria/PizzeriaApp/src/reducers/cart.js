function cartReducer(state = [], actions) {
  switch (actions.type) {
    case "ADD_ITEM": {
      state = [...state, actions.payload];
      return state;
    }
    //not used
    case "GET_ITEMS": {
      return state;
    }
    case "REMOVE_ITEM": {
      /* let a1 = [];
      let a2 = [];
      for (let i = 0; i < actions.payload; i++) {
        a1.push(state[i]);
      }
      for (let i = actions.payload + 1; i < state.length; i++) {
        a2.push(state[i]);
      }
      state = [...a1, ...a2];

      return state; */
      let allorders = [...state];
      let finalans = [];
      allorders.map((o) => {
        if (o.name !== actions.payload) {
          finalans.push(o);
        }
      });
      state = [...finalans];
      return state;
    }

    case "REMOVE_ALLITEMS": {
      return (state = []);
    }
    case "DECREASE_ITEM": {
      let index = -1;
      for (let i = 0; i < state.length; i++) {
        //console.log("state name" + state[i].name);

        if (state[i].name === actions.payload.name) {
          index = i;
          break;
        }
      }
      let ans = [];
      for (let i = 0; i < index; i++) {
        ans.push(state[i]);
      }
      for (let i = index + 1; i < state.length; i++) {
        ans.push(state[i]);
      }
      // console.log(ans);
      state = [...ans];
      return state;
    }
    default:
      return state;
  }
}

export default cartReducer;

/* let a1 = ans.splice(0, actions.payload);
let a2 = ans.splice(actions.payload + 1, ans.length);
ans = [...a1, ...a2];
console.log(ans); */
