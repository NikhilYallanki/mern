function userReducer(state = "", actions) {
  switch (actions.type) {
    case "LOGGED_IN":
      return (state = actions.payload);
    case "LOGGED_OUT":
      return (state = "");
    default:
      return state;
  }
}

export default userReducer;
