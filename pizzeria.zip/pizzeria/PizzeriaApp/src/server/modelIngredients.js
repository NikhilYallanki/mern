const mongoose = require("mongoose");
const ingredientsSchema = new mongoose.Schema({
  id: {
    type: Number,
  },
  tname: {
    type: String,
  },
  price: {
    type: Number,
  },
  image: {
    type: String,
  },
});
const ingredients = mongoose.model("ingredients", ingredientsSchema);

module.exports = ingredients;
