const mongoose = require("mongoose");

const pizzaSchema = new mongoose.Schema({
  id: {
    type: String,
  },
  type: {
    type: String,
  },
  price: {
    type: Number,
  },
  name: {
    type: String,
  },
  image: {
    type: String,
  },
  description: {
    type: String,
  },
  ingredients: {
    type: Array,
  },
  topping: {
    type: Array,
  },
});

const pizza = mongoose.model("pizzas", pizzaSchema);

module.exports = pizza;
