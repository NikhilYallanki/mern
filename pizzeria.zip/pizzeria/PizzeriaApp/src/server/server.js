const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const model = require("./modelPizza");
const modelIng = require("./modelIngredients");
const userModel = require("./modelUser");
const app = express();
app.use(express.json());
app.use(cors());

mongoose.connect("mongodb://localhost:27017/pizzeria", {
  useNewUrlParser: true,
});
//get all pizzas
app.get("/read", async (req, res) => {
  model.find({}, (e, result) => {
    if (e) res.send(e);
    res.send(result);
  });
});
//get all ingredients
app.get("/readIng", async (req, res) => {
  modelIng.find({}, (e, result) => {
    if (e) res.send(e);
    res.send(result);
  });
});
//get all previous orders (not used)
app.get("/orders", async (req, res) => {
  userModel.find({}, (e, result) => {
    if (e) res.send(e);
    else res.send(result);
  });
});
//get order history based on username
app.post("/orderHistory", async (req, res) => {
  const username = req.body.username;
  userModel.find({ username: username }, (e, result) => {
    if (e) console.log(e);
    else res.send(result[0].orders);
  });
});
//validate user
app.post("/users", async (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  userModel.find({ username: username, password: password }, (e, result) => {
    if (e) console.log("error" + e);
    else {
      if (result.length === 0) res.send(false);
      else res.send(true);
    }
  });
});
//new user
app.post("/insert", async (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  const addData = new userModel({
    username: username,
    password: password,
  });

  try {
    await addData.save();
    res.send(true);
  } catch (e) {
    //throws error if user exists as username should be unique
    res.send("exists");
  }
});
//existing user
app.post("/update", async (req, res) => {
  const username = req.body.username;
  const orders = req.body.orders;
  try {
    userModel.findOneAndUpdate(
      { username: username },
      {
        $push: {
          orders: orders,
        },
      },
      (e, result) => {
        if (e) console.log(e);
        else res.send(true);
      }
    );
  } catch (e) {
    console.log(e);
  }
});
app.get("/admin", async (req, res) => {
  userModel.find(
    {
      orders: {
        $elemMatch: { status: { $ne: "delivered" } },
      },
    },
    (e, result) => {
      if (e) console.log(e);
      res.send(result);
    }
  );
});
app.post("/adminUpdate", async (req, res) => {
  const username = req.body.username;
  const orderId = req.body.orderId;
  try {
    userModel.findOneAndUpdate(
      {
        username: username,
        orders: {
          $elemMatch: { orderId: orderId },
        },
      },
      {
        $set: {
          "orders.$.status": "delivered",
        },
      },
      (e, result) => {
        if (e) console.log(e);
        else res.send(true);
      }
    );
  } catch (e) {
    console.log(e);
  }
});
app.post("/adminActivityUpdate", async (req, res) => {
  const username = req.body.username;
  const orderId = req.body.orderId;
  const s = req.body.status;
  try {
    userModel.findOneAndUpdate(
      {
        username: username,
        orders: {
          $elemMatch: { orderId: orderId },
        },
      },
      {
        $set: {
          "orders.$.status": s,
        },
      },
      (e, result) => {
        if (e) console.log(e);
        else res.send(true);
      }
    );
  } catch (e) {
    console.log(e);
  }
});
app.listen(3001);
