import { useEffect, useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useDispatch, useSelector } from "react-redux";
import { deleteAllItems, deleteItem } from "../actions/cart";
import { add, decrease } from "../actions/cart";
import axios from "axios";
import showAlert from "./showAlert";
function ModalTest() {
  const [show, setShow] = useState(false);
  let [address, setAddress] = useState("");
  const [disabledButton, setDisabledButton] = useState(true);
  const [formattedOrders, setFormattedOrders] = useState([]);
  const [prices, setPrices] = useState(new Map());
  const username = useSelector((state) => state.userReducer);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const myOrders = useSelector((state) => state.cartReducer);
  const dispatch = useDispatch();
  //get updated total price for redux's cart state
  const getTotal = () => {
    let total = 0;
    myOrders.map((order) => {
      return (total = total + order.price);
    });

    return total;
  };
  const sendData = () => {
    let getCurrentOrders = [];
    myOrders.map((mo) => {
      return getCurrentOrders.push(mo.name);
    });
    const tot = getTotal();
    //send data to mongo in array of objects form
    const fobj = [
      {
        getCurrentOrders,
        tot,
        status: "ordered",
        orderId: Math.floor(Math.random() * 1000000000),
        address: address,
      },
    ];

    const doWork = async (req, res) => {
      await axios
        .post("http://localhost:3001/update", {
          username: username,
          orders: fobj,
        })
        .then((res) => {
          if (res) showAlert("Order Placed", "success", "center");
          else showAlert("Order failed", "danger", "center");
        });
    };
    doWork();
  };
  const checkIfLogged = () => {
    if (username.length > 0) {
      sendData();
      handleClose();
    } else {
      showAlert("Please Login before ordering", "danger", "center");
      handleClose();
    }
  };
  //keep watch on address textarea
  useEffect(() => {
    if (address.length > 0) setDisabledButton(false);
    else setDisabledButton(true);
  }, [disabledButton, address]);

  const handlePrices = () => {
    let map = new Map();
    myOrders.map((o) => {
      if (map.get(o.name) === undefined) map.set(o.name, o.price);
    });
    setPrices(map);
  };

  const handleFormatMyOrders = () => {
    let map = new Map();
    myOrders.map((o) => {
      if (map.get(o.name) === undefined) map.set(o.name, 1);
      else map.set(o.name, map.get(o.name) + 1);
    });
    //console.log(map);
    const iter = map[Symbol.iterator]();
    //const obj = Object.fromEntries(map);
    let finalarr = [];
    for (const m of iter) {
      //console.log(m);
      finalarr.push(m);
    }
    //console.log(finalarr);
    for (let i = 0; i < finalarr.length; i++) {
      let amt = finalarr[i][1] * parseInt(prices.get(finalarr[i][0]));
      //console.log(amt);
      finalarr[i].push(amt);
    }
    setFormattedOrders(finalarr);
    console.log(finalarr);
    //let keys = Object.keys(obj);
  };

  const handleIncrementItem = (name, index) => {
    for (let i = 0; i < myOrders.length; i++) {
      if (myOrders[i].name === name) {
        dispatch(add(myOrders[i]));
        break;
      }
    }
    for (let i = 0; i < formattedOrders.length; i++) {
      if (formattedOrders[i][0] === name) {
        formattedOrders[i][1] = formattedOrders[i][1] + 1;
        formattedOrders[i][2] =
          formattedOrders[i][1] * parseInt(prices.get(name));
      }
    }
  };

  const handleDecrementItem = (name, index) => {
    for (let i = 0; i < myOrders.length; i++) {
      if (myOrders[i].name === name) {
        dispatch(decrease(myOrders[i]));
        break;
      }
    }
    for (let i = 0; i < formattedOrders.length; i++) {
      if (formattedOrders[i][0] === name) {
        if (formattedOrders[i][1] > 1) {
          formattedOrders[i][1] = formattedOrders[i][1] - 1;
          formattedOrders[i][2] =
            formattedOrders[i][1] * parseInt(prices.get(name));
        } else {
          dispatch(deleteItem(name));
          handleDeleteFormat(name);
        }
      }
    }
  };

  const getUpdatedPrice = (val, name) => {
    let s = val * prices.get(name);
    return s;
  };
  const handleDeleteFormat = (name) => {
    let finalans = [];
    for (let i = 0; i < formattedOrders.length; i++) {
      console.log(finalans);
      if (formattedOrders[i][0] !== name) {
        console.log(formattedOrders[i][0]);
        finalans.push(formattedOrders[i]);
        console.log(finalans);
      }
    }

    setFormattedOrders([...finalans]);
    console.log(formattedOrders);
  };
  /* useEffect(() => {
    console.log(formattedOrders);
  }); */
  return (
    <>
      {/* button in navbar */}
      <Button
        style={{ marginLeft: "10px" }}
        variant="warning"
        onClick={() => {
          handleShow();
          getTotal();
          handlePrices();
          console.log(prices);
          handleFormatMyOrders();
        }}
      >
        <i className="fa fa-shopping-cart"> Shopping Cart</i>
      </Button>

      <Modal show={show} onHide={handleClose}>
        <Modal.Header>
          <Modal.Title>My Cart</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {myOrders.length > 0 ? (
            <>
              <div className="form-floating">
                <textarea
                  className="form-control"
                  id="floatingTextarea"
                  onChange={(e) => setAddress(e.target.value)}
                  value={address}
                  style={{ height: "100px" }}
                ></textarea>
                {/* warning indicator */}
                {address.length === 0 ? (
                  <p style={{ color: "red" }}>Please enter address</p>
                ) : null}
                <label htmlFor="floatingTextarea">Address</label>
              </div>
              <table className="table">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Name</th>
                    <th scope="col">Count</th>
                    <th scope="col">Price</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                  {formattedOrders.map((fo, index) => {
                    return (
                      <tr key={`tr_${index}`}>
                        <th scope="row">{index + 1}</th>
                        <td>{fo[0]}</td>
                        <td>
                          <button
                            className="btn btn-secondary btn-sm"
                            onClick={() => handleDecrementItem(fo[0], index)}
                            style={{
                              background: "rgb(104,104,104)",
                              border: "none",
                            }}
                          >
                            -
                          </button>
                          <button
                            id={`count_${index}`}
                            style={{
                              outline: "none",
                              border: "none",
                              background: "none",
                              cursor: "text",
                            }}
                          >
                            {fo[1]}
                          </button>
                          <button
                            className="btn btn-secondary btn-sm"
                            onClick={() => handleIncrementItem(fo[0], index)}
                            style={{
                              background: "rgb(104,104,104)",
                              border: "none",
                            }}
                          >
                            +
                          </button>
                        </td>
                        <td id={`price_${index}`}>
                          &#8377;{getUpdatedPrice(fo[1], fo[0])}
                        </td>
                        <td>
                          <button
                            type="button"
                            className="btn-close"
                            aria-label="Close"
                            onClick={() => {
                              dispatch(deleteItem(fo[0]));
                              handleDeleteFormat(fo[0]);
                            }}
                          ></button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr>
                    <td></td>
                    <td style={{ textAlign: "center" }}>
                      <b>Total</b>
                    </td>
                    <td></td>
                    <td>
                      <b>&#8377;{getTotal()}</b>
                    </td>
                  </tr>
                </tfoot>
              </table>
            </>
          ) : (
            "No items"
          )}
        </Modal.Body>
        <Modal.Footer>
          {myOrders.length > 0 ? (
            <>
              <Button
                variant="secondary"
                onClick={() => {
                  handleClose();
                  //window.location.reload();
                }}
              >
                Close
              </Button>
              <Button
                variant="primary"
                disabled={disabledButton}
                onClick={() => {
                  checkIfLogged();
                  setAddress("");
                  //add dipatch to empty cart
                  // eslint-disable-next-line no-unused-expressions
                  username ? dispatch(deleteAllItems()) : null;
                }}
              >
                Order
              </Button>
            </>
          ) : (
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
          )}
        </Modal.Footer>
      </Modal>
    </>
  );
}

export default ModalTest;

/* 
{myOrders.map((o, index) => {
  return (
    <tr key={index}>
      <th scope="row">{index + 1}</th>
      <td>{o.name}</td>
      <td>&#8377;{o.price}</td>
      <td>
        <button
          type="button"
          className="btn-close"
          aria-label="Close"
          onClick={() => {
            dispatch(deleteItem(index));
          }}
        ></button>
      </td>
    </tr>
  );
})} */
