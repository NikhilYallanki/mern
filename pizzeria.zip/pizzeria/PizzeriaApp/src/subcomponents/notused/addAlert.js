//replaced with showAlert

import { useState } from "react";
import "bootstrap/js/src/alert";
export default function AddAlert() {
  const [show] = useState(true);

  if (show) {
    return (
      <div class="alert alert-success" role="alert">
        <button
          type="button"
          class="close"
          data-dismiss="alert"
          aria-label="Close"
        >
          <span aria-hidden="true">&times;</span>
        </button>
        <strong>Item added!</strong>
      </div>
    );
  }
}
