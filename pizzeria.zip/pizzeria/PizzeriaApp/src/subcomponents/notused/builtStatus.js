//made for clean code

/* import { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
import { useDispatch, useSelector } from "react-redux";
import { deleteItem } from "../actions/cart";
function ModalTest() {
  const [show, setShow] = useState(false);
  const [showFailed, setShowFailed] = useState(false);
  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const handleFailedClose = () => setShowFailed(false);
  const handleFailedShow = () => setShowFailed(true);
  const myOrders = useSelector((state) => state.cartReducer);
  const dispatch = useDispatch();
  //total price of all pizzas in redux state mycart
  const getTotal = () => {
    let total = 0;
    myOrders.map((order) => {
      return (total = total + order.price);
    });

    return total;
  };

  const handleCountClick = () => {
    return myOrders.length ? handleShow() : handleFailedShow();
  };
  return (
    <>
      <Button
        style={{ marginLeft: "10px" }}
        variant="warning"
        onClick={() => {
          handleCountClick();
          getTotal();
        }}
      >
        <i className="fa fa-shopping-cart"> Shopping Cart</i>
      </Button>
      {myOrders.length > 0 ? (
        <Modal show={show} onHide={handleClose}>
          <Modal.Header>
            <Modal.Title>My Cart</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <table className="table">
              <thead>
                <tr>
                  <th scope="col">#</th>
                  <th scope="col">Name</th>
                  <th scope="col">Price</th>
                  <th scope="col"></th>
                </tr>
              </thead>
              <tbody>
                {myOrders.map((o, index) => {
                  return (
                    <tr key={index}>
                      <th scope="row">{index + 1}</th>
                      <td>{o.name}</td>
                      <td>{o.price}</td>
                      <td>
                        <button
                          type="button"
                          className="btn-close"
                          aria-label="Close"
                          onClick={() => {
                            dispatch(deleteItem(o));
                          }}
                        ></button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot>
                <tr>
                  <td></td>
                  <td>
                    <b>Total</b>
                  </td>
                  <td>
                    <b>&#8377;{getTotal()}</b>
                  </td>
                </tr>
              </tfoot>
            </table>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Close
            </Button>
            <Button
              variant="primary"
              onClick={() => {
                handleClose();
                alert("order placed");
                window.location.reload();
              }}
            >
              Order
            </Button>
          </Modal.Footer>
        </Modal>
      ) : (
        <Modal show={showFailed} onHide={handleFailedClose}>
          <Modal.Header>
            <Modal.Title>My Cart</Modal.Title>
          </Modal.Header>
          <Modal.Body>No items</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleFailedClose}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      )}
    </>
  );
}

export default ModalTest;
 */
