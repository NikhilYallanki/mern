//should be used in modal if items exist

/* import { useDispatch, useSelector } from "react-redux";
import { deleteItem } from "../actions/cart";

function CartContainsItems({ address, handleSetAddress }) {
  const dispatch = useDispatch();
  const myOrders = useSelector((state) => state.cartReducer);
  const getTotal = () => {
    let total = 0;
    myOrders.map((order) => {
      total = total + order.price;
    });

    return total;
  };
  const handleSetAddress = (e) => {
    setAddress(e.target.value);
  };
  return (
    <>
      <div className="form-floating">
        <textarea
          className="form-control"
          placeholder="Leave a comment here"
          id="floatingTextarea"
          onChange={(e) => {handleSetAddress}}
          value={address}
          style={{ height: "100px" }}
        ></textarea>
        <label htmlFor="floatingTextarea">Address</label>
      </div>
      <table className="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Price</th>
            <th scope="col"></th>
          </tr>
        </thead>
        <tbody>
          {myOrders.map((o, index) => {
            return (
              <tr key={index}>
                <th scope="row">{index + 1}</th>
                <td>{o.name}</td>
                <td>&#8377;{o.price}</td>
                <td>
                  <button
                    type="button"
                    className="btn-close"
                    aria-label="Close"
                    onClick={() => {
                      dispatch(deleteItem(o));
                    }}
                  ></button>
                </td>
              </tr>
            );
          })}
        </tbody>
        <tfoot>
          <tr>
            <td></td>
            <td>
              <b>Total</b>
            </td>
            <td>
              <b>&#8377;{getTotal()}</b>
            </td>
          </tr>
        </tfoot>
      </table>
    </>
  );
}

export default CartContainsItems;
 */
