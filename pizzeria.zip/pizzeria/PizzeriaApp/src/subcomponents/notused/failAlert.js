//replaced with showAlert
import Alert from "react-bootstrap/Alert";

function FailAlert() {
  return (
    <Alert variant="danger" style={{ margin: "auto", width: "100%" }}>
      <p>Add Items to cart to order</p>
    </Alert>
  );
}

export default FailAlert;
