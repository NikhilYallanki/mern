//replaced with showAlert
import Alert from "react-bootstrap/Alert";

function SuccessAlert({ address }) {
  return (
    <Alert variant="success" style={{ margin: "auto", width: "100%" }}>
      <Alert.Heading>Order Placed Successfully</Alert.Heading>
      <p>Pizza will be delivered to {address} within 2hrs</p>
    </Alert>
  );
}

export default SuccessAlert;
