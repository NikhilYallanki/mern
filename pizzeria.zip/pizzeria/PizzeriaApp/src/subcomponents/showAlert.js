//  http://bootstrap-notify.remabledesigns.com/
import $ from "jquery";
export default function showAlert(name, type, align = "right") {
  $.notify(
    {
      message: name,
    },

    {
      element: "body",
      type: type,
      allow_dismiss: false,

      placement: {
        from: "top",
        align: align,
      },
      offset: {
        x: 0,
        y: 100,
      },
      spacing: 10,
      z_index: 1031,
      delay: 2000,
      timer: 1000,
      animate: {
        enter: "animate__animated animate__fadeInDown",
        exit: "animate__animated animate__fadeOutUp",
      },
      onShow: function () {
        this.css({ width: "auto", height: "auto" });
      },
    }
  );
}
